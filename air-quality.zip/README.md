# analisis_data
# analisis_data
